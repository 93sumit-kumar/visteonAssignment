const Book = require("../../models/bookModel");

/**
 * @description: Book Add
 */
exports.addNewBook = async (req, res, next) => {
  try {
    let bookId = req.body.bookId;
    let bookName = req.body.bookName;
    let isbn = req.body.isbn;
    let author = req.body.author;
    // check if user already exist
    // Validate if user exist in our database
    const oldBook = await Book.findOne({ email });

    if (oldBook) {
      return res.status(409).send("User Already Exist. Please Login");
    }
    const newRecord = new Book({
      bookId: bookId,
      bookName: bookName,
      isbn: isbn,
      author: author,
    });
    newRecord
      .save()
      .then(() => {
        res.status(200).send({
          status: 200,
          message: "Record Saved to database",
        });
      })
      .catch((error) => {
        res.status(400).send({
          status: 400,
          message: "unable to save to database" + error,
        });
      });
  } catch (error) {
    next(error);
  }
};

/**
 * @description: Fetch All books here
 */
exports.getBookList = async (req, res, next) => {
  try {
    Book.find()
      .then((response) => {
        if (response == null) {
          res.status(400).send({
            status: 400,
            message: "No record found" + err,
          });
        }
        res.status(200).send({
          status: 200,
          message: "All Records!",
          records: response,
        });
      })
      .catch((err) => {
        console.log("fetch error", err);
      });
  } catch (error) {
    next(error);
  }
};
