const express = require("express");
const app = express();
const middleware = require("../middleware/middleware");
const userController = require("../controller/userController/userController");
const bookController = require("../controller/bookController/bookController");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.post("/login", middleware.loginValidation, userController.login);
app.post("/signup", middleware.signupValidation, userController.signup);

app.post(
  "/addNewBook",
  middleware.verifyToken,
  middleware.bookValidation,
  bookController.addNewBook
);
app.get("/getBookList", middleware.verifyToken, bookController.getBookList);

module.exports = app;
