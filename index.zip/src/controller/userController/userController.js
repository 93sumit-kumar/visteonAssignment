const bcrypt = require("bcrypt");
const saltRounds = 10;
const User = require("../../models/userModel");
const jwt = require("jsonwebtoken");

require("dotenv").config();
/**
 * @describe : User signup with username and password
 * @params : username, password
 * @return: sucess/error with JWT token
 */
exports.signup = async (req, res, next) => {
  try {
    let username = req.body.username;
    let password = req.body.password;
    // check if user already exist
    // Validate if user exist in our database
    const oldUser = await User.findOne({ username });

    if (oldUser) {
      return res.status(409).send("User Already Exist. Please Login");
    }
    bcrypt.genSalt(saltRounds, function (err, salt) {
      bcrypt.hash(password, salt, function (err, hash) {
        passwordHash = hash;
        const newUser = new User({
          username: username,
          password: hash,
        });
        /** JWT token generation */
        const accessToken = jwt.sign(
          { userId: newUser._id },
          process.env.JWT_SECRET,
          { expiresIn: "1d" }
        );
        newUser.accessToken = accessToken;
        newUser
          .save()
          .then(() => {
            res.status(200).send({
              status: 200,
              message: "User registered successfully!",
              data: accessToken,
            });
          })
          .catch((error) => {
            res.status(400).send({
              status: 400,
              message: "unable to save to database" + error,
            });
          });
      });
    });
  } catch (error) {
    next(error);
  }
};

/**
 * @description: login module
 * @params : username, password
 * @return : success/error with JWT token
 */
exports.login = async (req, res, next) => {
  try {
    let username = req.body.username;
    let password = req.body.password;
    const user = User.findOne({ username: username })
      .then((response) => {
        if (response == null) {
          res.send({
            status: 404,
            message: "Username doest not exists!",
          });
        } else {
          const dbPassword = response.password;
          bcrypt.compare(password, dbPassword, function (err, result) {
            if (err) {
              res.send({
                status: 200,
                message: "Unable to fetch record" + err,
              });
            } else if (result) {
              const accessToken = jwt.sign(
                { user: response._id },
                process.env.JWT_SECRET,
                { expiresIn: "1d" }
              );
              User.findByIdAndUpdate(
                response._id,
                { accessToken: accessToken },
                function (err, docs) {
                  if (err) {
                    console.log(err);
                  } else {
                    // console.log("Updated User : ", docs);
                  }
                }
              );
              res.send({
                status: 200,
                message: "Login Successfully!",
                accessToken: accessToken,
              });
            } else {
              res.send({
                status: 404,
                message: "Password doesn't matched!",
              });
            }
          });
        }
      })
      .catch((err) => {
        console.log("login error", err);
      });
  } catch (error) {
    next(error);
  }
};
