const mongoose = require("mongoose");
const path = require("path");
require("dotenv").config();
const dbUrl = process.env.MongoDBUrl;

mongoose
  .connect(dbUrl)
  .then(() => {
    console.log("Database connected");
  })
  .catch((e) => {
    console.log("Error! ", e);
  });
