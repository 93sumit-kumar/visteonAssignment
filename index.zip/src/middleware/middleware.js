const validator = require("validator");
// const joi = require("joi");
const jwt = require("jsonwebtoken");
require("dotenv").config();

const verifyToken = (req, res, next) => {
  console.log("Token: ", req.headers["x-access-token"]);
  const token = req.headers["x-access-token"];

  if (!token) {
    return res.status(403).send({
      success: 0,
      statuCode: 403,
      message: "A token is required for authentication",
    });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded;
    next();
  } catch (err) {
    res.status(401).send({
      statusCode: 401,
      message: "Invalid Token",
    });
    next(err);
  }
  //   return next();
};
/**
 *
 * @description : signup validation
 */
const signupValidation = (req, res, next) => {
  try {
    let username = req.body.username;
    let password = req.body.password;
    if (validator.isEmpty(username) == true) {
      if (validator(username).isEmail() == true) {
        res.status(404).send({
          status: 404,
          message: "Email format is incorrect!",
        });
      } else {
        res.status(404).send({
          status: 404,
          message: "Email can not be empty!",
        });
      }
    } else if (validator.isEmpty(password) == true) {
      res.status(404).send({
        status: 404,
        message: "Password can not be empty!",
      });
    }
    next();
  } catch (error) {
    next(error);
  }
};

/**
 *
 * @description : login validation
 */
const loginValidation = (req, res, next) => {
  try {
    let username = req.body.username;
    let password = req.body.password;
    if (validator.isEmpty(username) == true) {
      console.log(validator.isEmail(username), "email");
      if (validator.isEmail(username) == true) {
        res.status(404).send({
          status: 404,
          message: "Username format is incorrect!",
        });
      } else {
        res.status(404).send({
          status: 404,
          message: "Username can not be empty!",
        });
      }
    } else if (validator.isEmpty(password) == true) {
      res.status(404).send({
        status: 404,
        message: "Password can not be empty!",
      });
    }
    next();
  } catch (error) {
    next(error);
  }
};

/**
 *
 * @description : book validation
 */
const bookValidation = (req, res, next) => {
  try {
    let bookId = req.body.bookId;
    let bookName = req.body.bookName;
    let isbn = req.body.isbn;
    let author = req.body.author;
    if (validator.isEmpty(bookName) == true) {
      res.status(404).send({
        status: 404,
        message: "Title can not be empty!",
      });
    } else if (bookId.length == 0) {
      res.status(404).send({
        status: 404,
        message: "Category Id can not be empty!",
      });
    } else if (validator.isEmpty(isbn)) {
      res.status(404).send({
        status: 404,
        message: "Isbn can not be empty!",
      });
    } else if (validator.isEmpty(author) == true) {
      res.status(404).send({
        status: 404,
        message: "Author can not be empty!",
      });
    }
    next();
  } catch (error) {
    next(error);
  }
};

module.exports = {
  verifyToken,
  signupValidation,
  loginValidation,
  bookValidation,
};
